import { Link } from 'react-router-dom'

// Botão reutilizável.
// Props: texto, to (opcional: vira um Link), onClick, type, variante
function Button({ texto, to, onClick, type = 'button', variante = 'primario' }) {
  const classe = `botao botao-${variante}`

  if (to) {
    return (
      <Link to={to} className={classe}>
        {texto}
      </Link>
    )
  }

  return (
    <button type={type} className={classe} onClick={onClick}>
      {texto}
    </button>
  )
}

export default Button
