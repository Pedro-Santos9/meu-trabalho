import Button from './Button.jsx'

// Card reutilizável. Todos os dados chegam por Props.
function Card({ titulo, imagem, descricao, preco, categoria }) {
  return (
    <article className="card">
      <img src={imagem} alt={titulo} className="card-imagem" />
      <div className="card-corpo">
        <span className="card-categoria">{categoria}</span>
        <h3 className="card-titulo">{titulo}</h3>
        <p className="card-descricao">{descricao}</p>
        <div className="card-rodape">
          <strong className="card-preco">
            {preco.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
          </strong>
          <Button texto="Comprar" onClick={() => alert(`${titulo} adicionado ao carrinho!`)} />
        </div>
      </div>
    </article>
  )
}

export default Card
