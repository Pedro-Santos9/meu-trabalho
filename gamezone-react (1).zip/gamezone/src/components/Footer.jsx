function Footer() {
  return (
    <footer className="footer">
      <p>© {new Date().getFullYear()} GameZone - Loja Virtual de Jogos</p>
      <p>Projeto acadêmico desenvolvido com React, Vite e React Router.</p>
    </footer>
  )
}

export default Footer
