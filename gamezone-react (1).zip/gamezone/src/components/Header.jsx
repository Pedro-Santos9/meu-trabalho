import { Link } from 'react-router-dom'
import Menu from './Menu.jsx'

function Header() {
  return (
    <header className="header">
      <Link to="/" className="logo">
        🎮 GameZone
      </Link>
      <Menu />
    </header>
  )
}

export default Header
