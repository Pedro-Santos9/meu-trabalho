import { NavLink } from 'react-router-dom'

// Lista de links do menu. Para criar uma nova rota no menu,
// basta adicionar um novo objeto neste array.
const links = [
  { to: '/', texto: 'Início' },
  { to: '/produtos', texto: 'Produtos' },
  { to: '/sobre', texto: 'Sobre' },
  { to: '/contato', texto: 'Contato' },
]

function Menu() {
  return (
    <nav className="menu">
      {links.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.to === '/'}
          className={({ isActive }) => (isActive ? 'menu-link ativo' : 'menu-link')}
        >
          {link.texto}
        </NavLink>
      ))}
    </nav>
  )
}

export default Menu
