// Array de objetos com os jogos da loja.
// Esses dados são percorridos com .map() na página Produtos
// e enviados para o componente Card por meio de Props.
const produtos = [
  {
    id: 1,
    titulo: 'Cyber Racer',
    imagem: '/images/cyber-racer.svg',
    descricao: 'Corridas futuristas em alta velocidade pelas ruas de uma cidade neon.',
    preco: 149.9,
    categoria: 'Corrida',
  },
  {
    id: 2,
    titulo: 'Dragon Quest',
    imagem: '/images/dragon-quest.svg',
    descricao: 'Uma grande aventura de RPG com dragões, magias e masmorras secretas.',
    preco: 199.9,
    categoria: 'RPG',
  },
  {
    id: 3,
    titulo: 'Space War',
    imagem: '/images/space-war.svg',
    descricao: 'Batalhas espaciais épicas com naves personalizáveis e modo online.',
    preco: 129.9,
    categoria: 'Ação',
  },
  {
    id: 4,
    titulo: 'Pixel Farm',
    imagem: '/images/pixel-farm.svg',
    descricao: 'Cuide da sua fazenda, plante, colha e faça amizade com os vizinhos.',
    preco: 59.9,
    categoria: 'Simulação',
  },
  {
    id: 5,
    titulo: 'Ninja Shadow',
    imagem: '/images/ninja-shadow.svg',
    descricao: 'Furtividade e combate em uma jornada ninja pelo Japão feudal.',
    preco: 169.9,
    categoria: 'Aventura',
  },
  {
    id: 6,
    titulo: 'Soccer Pro',
    imagem: '/images/soccer-pro.svg',
    descricao: 'O melhor do futebol com times, campeonatos e modo carreira completo.',
    preco: 179.9,
    categoria: 'Esporte',
  },
]

export default produtos
