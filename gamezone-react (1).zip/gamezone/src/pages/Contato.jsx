import { useState } from 'react'
import Button from '../components/Button.jsx'

function Contato() {
  const [enviado, setEnviado] = useState(false)

  function handleSubmit(evento) {
    evento.preventDefault() // evita recarregar a página
    setEnviado(true)
    evento.target.reset()
  }

  return (
    <section className="pagina-texto">
      <h1>Contato</h1>
      <p>Preencha o formulário abaixo e entraremos em contato.</p>

      <form className="formulario" onSubmit={handleSubmit}>
        <label htmlFor="nome">Nome</label>
        <input id="nome" type="text" placeholder="Seu nome" required />

        <label htmlFor="email">E-mail</label>
        <input id="email" type="email" placeholder="seu@email.com" required />

        <label htmlFor="mensagem">Mensagem</label>
        <textarea id="mensagem" rows="5" placeholder="Escreva sua mensagem" required />

        <Button texto="Enviar mensagem" type="submit" />
      </form>

      {enviado && <p className="sucesso">✅ Mensagem enviada com sucesso!</p>}
    </section>
  )
}

export default Contato
