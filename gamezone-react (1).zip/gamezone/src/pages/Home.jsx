import Button from '../components/Button.jsx'

function Home() {
  return (
    <section className="hero">
      <h1>Bem-vindo à GameZone</h1>
      <p>
        Sua loja virtual de jogos. Encontre aventuras, corridas, RPGs e muito mais
        pelos melhores preços.
      </p>
      <p className="hero-sobre">
        Este projeto demonstra o uso de <strong>Componentes</strong>,{' '}
        <strong>Props</strong> e <strong>Rotas</strong> com React.
      </p>
      <div className="hero-botoes">
        <Button texto="Ver produtos" to="/produtos" />
        <Button texto="Fale conosco" to="/contato" variante="secundario" />
      </div>
    </section>
  )
}

export default Home
