import Button from '../components/Button.jsx'

function NotFound() {
  return (
    <section className="hero">
      <h1>404</h1>
      <p>Ops! A página que você procura não existe.</p>
      <Button texto="Voltar ao início" to="/" />
    </section>
  )
}

export default NotFound
