import Card from '../components/Card.jsx'
import produtos from '../data/produtos.js'

function Produtos() {
  return (
    <section>
      <h1>Nossos Produtos</h1>
      <div className="grade">
        {produtos.map((produto) => (
          <Card
            key={produto.id}
            titulo={produto.titulo}
            imagem={produto.imagem}
            descricao={produto.descricao}
            preco={produto.preco}
            categoria={produto.categoria}
          />
        ))}
      </div>
    </section>
  )
}

export default Produtos
