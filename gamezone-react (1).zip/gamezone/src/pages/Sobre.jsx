function Sobre() {
  return (
    <section className="pagina-texto">
      <h1>Sobre a aplicação</h1>
      <p>
        A GameZone é uma aplicação web criada como atividade prática avaliativa de
        React.js. Ela simula uma loja virtual de jogos e foi desenvolvida para
        praticar os principais conceitos da biblioteca.
      </p>
      <h2>Tecnologias utilizadas</h2>
      <ul>
        <li>React (componentes funcionais)</li>
        <li>Vite (ferramenta de build e servidor de desenvolvimento)</li>
        <li>React Router DOM (navegação entre páginas)</li>
      </ul>
      <h2>Conceitos aplicados</h2>
      <ul>
        <li>Componentização: Header, Footer, Menu, Card e Button</li>
        <li>Props: envio de dados dos jogos para o componente Card</li>
        <li>Rotas: /, /produtos, /sobre, /contato e página 404</li>
      </ul>
    </section>
  )
}

export default Sobre
